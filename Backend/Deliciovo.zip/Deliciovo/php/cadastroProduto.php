<?php
include "mysqlconecta.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (!empty($_POST['nome']) && !empty($_POST['descricao']) && !empty($_POST['peso']) && !empty($_POST['unidade']) && !empty($_POST['custo']) && !empty($_POST['valor'])) {
        
        $nome = $_POST['nome'];
        $descricao = $_POST['descricao'];
        $peso = (float) $_POST['peso'];
        $unidade = $_POST['unidade'];
        $custo = (float) $_POST['custo'];
        $valor = (float) $_POST['valor'];
        
        $query = "INSERT INTO produtos (pro_nome, pro_desc, pro_peso, pro_uniMed, pro_custo, pro_valor) 
                  VALUES ('$nome', '$descricao', $peso, '$unidade', $custo, $valor)";
        
        if (mysqli_query($conexao, $query)) {
            header("Location: cadastroProduto.php");
            exit();
        } else {
            echo "<p>Erro ao adicionar produto: " . mysqli_error($conexao) . "</p>";
        }
    } else {
        echo "<p>Preencha todos os campos.</p>";
    }
}

$conexao->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Adicionar Produto</title>
    <link rel="stylesheet" href="../css/style.css">
</head>
<body>

    <div class="container-form">
        <h1 class="subtitle red SdarkRed">Adicionar Produto</h1>
        <form class="bold title redBC mediumBS solid light-redBT" action="" method="POST">
            <div class="form-group">
                <label for="nome">Nome do Produto:</label>
                <input type="text" id="nome" name="nome" required>
            </div>
            <div class="form-group">
                <label for="descricao">Descrição:</label>
                <textarea id="descricao" name="descricao" rows="6" required></textarea>
            </div>
            <div class="form-group">
                <label for="peso">Peso:</label>
                <input type="number" step="0.01" id="peso" name="peso" required>
            </div>
            <div class="form-group">
                <label for="unidade">Unidade de Medida (ex: kg, g):</label>
                <input type="text" id="unidade" name="unidade" maxlength="2" required>
            </div>
            <div class="form-group">
                <label for="custo">Custo:</label>
                <input type="number" step="0.01" id="custo" name="custo" required>
            </div>
            <div class="form-group">
                <label for="valor">Valor de Venda:</label>
                <input type="number" step="0.01" id="valor" name="valor" required>
            </div>
            <button type="submit">Adicionar Produto</button>
        </form>
    </div>
    
</body>
</html>
