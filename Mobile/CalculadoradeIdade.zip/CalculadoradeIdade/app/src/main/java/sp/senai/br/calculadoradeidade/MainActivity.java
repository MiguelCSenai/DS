package sp.senai.br.calculadoradeidade;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    EditText etAno;
    TextView tvIdade;

    ConstraintLayout clPrincipal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etAno = findViewById(R.id.etAno);
        tvIdade = findViewById(R.id.tvIdade);
        clPrincipal = findViewById(R.id.clPrincipal);
        tvIdade.setText(null);

    }

    public void calcular(View c){

        int iAnoNasc = Integer.parseInt(etAno.getText().toString());

        Calendar data = Calendar.getInstance();
        int iAnoAtual = data.get(Calendar.YEAR);

        int iIdade = iAnoAtual-iAnoNasc;

        tvIdade.setText("Você tem "+iIdade+" anos");

        if (iIdade<6){

            clPrincipal.setBackgroundColor(Color.parseColor("#FACADA"));
            tvIdade.setTextColor(Color.parseColor("#000000"));

        } else if (iIdade < 11) {

            clPrincipal.setBackgroundColor(Color.rgb(255, 128, 0));
            tvIdade.setTextColor(Color.rgb(255, 255, 255));

        } else if (iIdade < 50) {

            clPrincipal.setBackgroundColor(Color.parseColor("#00FF00"));
            tvIdade.setTextColor(Color.parseColor("#FFFFFF"));

        } else{

            clPrincipal.setBackgroundColor(Color.parseColor("#FF0000"));
            tvIdade.setTextColor(Color.parseColor("#FFFFFF"));

        }

        etAno.setText(null);
        etAno.requestFocus();

    }

}