package sp.senai.br.media;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etNome;
    EditText etNota1;
    EditText etNota2;

    TextView tvMedia;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etNome = findViewById(R.id.etNome);
        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        tvMedia = findViewById(R.id.tvMedia);
        tvMedia.setText(null);

    }

    public void calcular(View c){

        String sNome = etNome.getText().toString();

        float fNota1 = Float.parseFloat(etNota1.getText().toString());
        float fNota2 = Float.parseFloat(etNota2.getText().toString());

        Float fMedia = (fNota1 + fNota2) / 2;

        tvMedia.setText("A média das notas do(a) aluno(a) "+sNome+" é "+fMedia);

    }

    public  void  limpar(View l){

        tvMedia.setText(null);
        etNome.setText(null);
        etNota1.setText(null);
        etNota2.setText(null);
        etNome.requestFocus();


    }

}