package sp.senai.br.calculadorasimples;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    ConstraintLayout clPrincipal;

    EditText etV1, etV2;

    TextView tvResultado;

    Button btnP,  btnM, btnT, btnD, btnClear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        clPrincipal = findViewById(R.id.clPrincipal);
        etV1 = findViewById(R.id.etV1);
        etV2 = findViewById(R.id.etV2);
        tvResultado = findViewById(R.id.tvResultado);
        btnP = findViewById(R.id.btnP);
        btnM = findViewById(R.id.btnM);
        btnT = findViewById(R.id.btnT);
        btnD = findViewById(R.id.btnD);
        btnClear = findViewById(R.id.btnClear);
        tvResultado.setText(null);

        limpeza();

    }

    public void adicao(View s){

        float fVl1, fVl2, fResult;
        fVl1 = Float.parseFloat(etV1.getText().toString());
        fVl2 = Float.parseFloat(etV2.getText().toString());
        fResult = fVl1 + fVl2;

        tvResultado.setText(String.valueOf(fResult));

        enable(false);

    }
    public void subtracao(View s){

        float fVl1, fVl2, fResult;
        fVl1 = Float.parseFloat(etV1.getText().toString());
        fVl2 = Float.parseFloat(etV2.getText().toString());
        fResult = fVl1 - fVl2;

        tvResultado.setText(String.valueOf(fResult));

        enable(false);

        if (fResult < 0){

            clPrincipal.setBackgroundColor(Color.rgb(0,0,0));
            tvResultado.setTextColor(Color.parseColor("#ffffff"));

        }

    }
    public void multiplicacao(View s){

        float fVl1, fVl2, fResult;
        fVl1 = Float.parseFloat(etV1.getText().toString());
        fVl2 = Float.parseFloat(etV2.getText().toString());
        fResult = fVl1 * fVl2;

        tvResultado.setText(String.valueOf(fResult));

        enable(false);

    }
    public void divisao(View s){

        float fVl1, fVl2, fResult;
        fVl1 = Float.parseFloat(etV1.getText().toString());
        fVl2 = Float.parseFloat(etV2.getText().toString());
        fResult = fVl1 / fVl2;

        tvResultado.setText(String.valueOf(fResult));

        enable(false);

    }
    public void limpar(View s){

        limpeza();

    }

    public void limpeza(){

        etV1.setText(null);
        etV2.setText(null);
        tvResultado.setText(null);
        etV1.requestFocus();
        enable(true);

        clPrincipal.setBackgroundColor(Color.rgb(255,255,255));
        tvResultado.setTextColor(Color.parseColor("#000000"));


    }

    public void enable(boolean lFaz){

            etV1.setEnabled(lFaz);
            etV2.setEnabled(lFaz);
            btnD.setEnabled(lFaz);
            btnT.setEnabled(lFaz);
            btnM.setEnabled(lFaz);
            btnP.setEnabled(lFaz);
            btnClear.setEnabled(!lFaz);


    }

}