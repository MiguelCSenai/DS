package sp.senai.br.genero;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText etNome;

    RadioGroup rgGenero;

    RadioButton rbMasc, rbFem;

    Button btnAcao;

    TextView tvResposta;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etNome = findViewById(R.id.etNome);
        rgGenero = findViewById(R.id.rgGenero);
        rbMasc = findViewById(R.id.rbMasc);
        rbFem = findViewById(R.id.rbFem);
        btnAcao = findViewById(R.id.btnAcao);
        tvResposta = findViewById(R.id.tvResposta);

        tvResposta.setText(null);

    }

    public void acao(View a){

        if (btnAcao.getText().equals("Exibir")){

            if (!etNome.getText().toString().equals("")){

                btnAcao.setText("Limpar");
                etNome.setEnabled(false);
                rbMasc.setEnabled(false);
                rbFem.setEnabled(false);
                if (rbFem.isChecked()){

                    tvResposta.setText(etNome.getText().toString()+", você é do gênero feminino");

                }else{

                    tvResposta.setText(etNome.getText().toString()+", você é do gênero masculino");

                }

            }else {

                Toast.makeText(this, "Necessário preencher todos os campos", Toast.LENGTH_LONG);
                etNome.requestFocus();

            }

        }else{

            btnAcao.setText("Exibir");
            tvResposta.setText(null);
            etNome.setText(null);
            etNome.setEnabled(true);
            rbMasc.setEnabled(true);
            rbFem.setEnabled(true);
            rbFem.setChecked(true);
            etNome.setEnabled(true);
            etNome.requestFocus();

        }

    }

}