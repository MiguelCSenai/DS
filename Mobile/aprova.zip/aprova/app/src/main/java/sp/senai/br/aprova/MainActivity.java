package sp.senai.br.aprova;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    ConstraintLayout clPrincipal;

    EditText etNota1, etNota2;

    Button btnCalc, btnClear;

    TextView tvStatus, tvNota;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        clPrincipal = findViewById(R.id.clPrincipal);
        etNota1 = findViewById(R.id.etNota1);
        etNota2 = findViewById(R.id.etNota2);
        btnCalc = findViewById(R.id.btnCalc);
        btnClear = findViewById(R.id.btnClear);
        tvStatus = findViewById(R.id.tvStatus);
        tvNota = findViewById(R.id.tvNota);

    }

    public void calc(View c){

        float fNota1 = Float.parseFloat(etNota1.getText().toString());
        float fNota2 = Float.parseFloat(etNota2.getText().toString());

        float fMedia = (fNota1 + fNota2) / 2;

        tvNota.setText("Média "+fMedia);

        if (fMedia >= 6) {

            tvStatus.setText("Aluno Aprovado");
            clPrincipal.setBackgroundColor(Color.rgb(0, 255, 0));
            tvStatus.setTextColor(Color.rgb(255, 255, 255));
            tvNota.setTextColor(Color.rgb(255, 255, 255));

        }else if(fMedia >=5){

            tvStatus.setText("Aluno em Recuperação");
            clPrincipal.setBackgroundColor(Color.rgb(255, 255, 0));
            tvStatus.setTextColor(Color.rgb(0, 0, 0));
            tvNota.setTextColor(Color.rgb(0, 0, 0));

        }else{

            tvStatus.setText("Aluno Reprovado");
            clPrincipal.setBackgroundColor(Color.rgb(255, 0, 0));
            tvStatus.setTextColor(Color.rgb(255, 255, 255));
            tvNota.setTextColor(Color.rgb(255, 255, 255));

        }

    }

    public void clear(View c){

        etNota1.setText(null);
        etNota2.setText(null);
        tvStatus.setText(null);
        tvNota.setText(null);
        clPrincipal.setBackgroundColor(Color.parseColor("#ffffff"));
        tvStatus.setTextColor(Color.rgb(0, 0, 0));
        tvNota.setTextColor(Color.rgb(0, 0, 0));
        etNota1.requestFocus();

    }

}