package sp.senai.br.combustivel;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    TextView tvGasolina, tvEtanol, tvMelhor;

    Button btnCalc;

    EditText etValorGas, etGas, etValorEtanol, etEtanol;

    ConstraintLayout clPrincipal;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {



        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        tvEtanol = findViewById(R.id.tvEtanol);
        tvGasolina = findViewById(R.id.tvGasolina);
        tvMelhor = findViewById(R.id.tvMelhor);
        btnCalc = findViewById(R.id.btnCalc);
        etEtanol = findViewById(R.id.etEtanol);
        etValorEtanol = findViewById(R.id.etValorEtanol);
        etGas = findViewById(R.id.etGas);
        etValorGas = findViewById(R.id.etValorGas);
        clPrincipal = findViewById(R.id.clPrincipal);

    }

    public void calcular(View v) {

        String strValorGas = etValorGas.getText().toString();
        String strValorEtanol = etValorEtanol.getText().toString();
        String strAutonomiaGas = etGas.getText().toString();
        String strAutonomiaEtanol = etEtanol.getText().toString();

        if (strValorGas.isEmpty() || strValorEtanol.isEmpty() || strAutonomiaGas.isEmpty() || strAutonomiaEtanol.isEmpty()) {
            tvMelhor.setText("Por favor, preencha todos os campos!");
            return;
        }

        float fValorGas = Float.parseFloat(strValorGas);
        float fValorEtanol = Float.parseFloat(strValorEtanol);
        float fAutonomiaGas = Float.parseFloat(strAutonomiaGas);
        float fAutonomiaEtanol = Float.parseFloat(strAutonomiaEtanol);

        float fVTEtanol = fValorEtanol / fAutonomiaEtanol;
        float fVTGas = fValorGas / fAutonomiaGas;

        tvGasolina.setText("Valor total da gasolina: " + fVTGas);
        tvEtanol.setText("Valor total do etanol: " + fVTEtanol);

        if (fVTEtanol > fVTGas) {
            tvMelhor.setText("A melhor opção é a gasolina.");
            clPrincipal.setBackgroundColor(Color.rgb(100, 200, 100));
        } else if (fVTEtanol < fVTGas) {
            tvMelhor.setText("A melhor opção é o etanol.");
            clPrincipal.setBackgroundColor(Color.rgb(100, 100, 200));
        } else {
            tvMelhor.setText("Qualquer um!");
            clPrincipal.setBackgroundColor(Color.rgb(100, 200, 200));
        }
    }


}