package sp.senai.br.adivinhe;

import android.graphics.Color;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    ConstraintLayout clPrincipal;
    EditText etPalpite;
    Button btnPalpite, btnAgain;
    TextView tvAnswer;
    int iNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.clPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        etPalpite = findViewById(R.id.etPalpite);
        btnPalpite = findViewById(R.id.btnPalpite);
        btnAgain = findViewById(R.id.btnAgain);
        tvAnswer = findViewById(R.id.tvAwnser);
        clPrincipal = findViewById(R.id.clPrincipal);


        iNum = (int)(Math.random() * 100) + 1;

        btnPalpite.setOnClickListener(v -> chute());
        btnAgain.setOnClickListener(v -> restart());
    }
    public void restart() {
        clPrincipal.setBackgroundColor(Color.rgb(255, 255, 255));
        iNum = (int)(Math.random() * 100) + 1;
        tvAnswer.setText("Boa Sorte!");
        etPalpite.setText(null);
        etPalpite.requestFocus();
    }

    public void chute() {

            int palpite = Integer.parseInt(etPalpite.getText().toString());

            if (palpite < iNum) {
                tvAnswer.setText("Não é esse 😢, tente um maior.");
                clPrincipal.setBackgroundColor(Color.rgb(255, 100, 100));
                etPalpite.setText(null);
                etPalpite.requestFocus();
            } else if (palpite > iNum) {
                tvAnswer.setText("Não é esse 😢, tente um menor");
                clPrincipal.setBackgroundColor(Color.rgb(255, 100, 100));
                etPalpite.setText(null);
                etPalpite.requestFocus();
            }else if(etPalpite.getText().toString() == null){

                clPrincipal.setBackgroundColor(Color.rgb(255, 255, 255));
                tvAnswer.setText("Digite um numero.");
                etPalpite.setText(null);
                etPalpite.requestFocus();

            }else {
                tvAnswer.setText("Parabéns VOCÊ ACERTOU!!! 😎🤩😜👏🎆");
                clPrincipal.setBackgroundColor(Color.rgb(100, 255, 100));
            }
        }
    }

