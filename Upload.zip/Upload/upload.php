<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Upload de Arquivo TXT</title>
    <link rel="stylesheet" href="style.css">
</head>

<body>

    <h1>Upload de Arquivo TXT</h1>

    <form action="processar.php" enctype="multipart/form-data" method="post">

        <label for="arquivo">Escolha o arquivo TXT:</label>
        <input type="file" name="arquivo" id="arquivo" accept=".txt" required><br><br>

        <label for="conteudo">Conteúdo do Arquivo</label><br>
        <textarea name="conteudo" id="conteudo" rows="10" cols="50" readonly></textarea><br><br>

        <div class="progresso">

            <div class="progresso-barra"></div>

        </div>

        <button onclick="lerArquivo()">Carregar Conteúdo</button>
        <button type="submit" name="salvar">Salvar no Banco de Dados</button>

    </form>


    <script>

        function lerArquivo() {

            const input = document.getElementById('arquivo');
            const textarea = document.getElementById('conteudo');
            const file = input.files[0];

            if (file) {
                
                const reader = new FileReader();

                reader.onload = function(e){

                    textarea.value = e.target.result;

                };

                reader.readAsText(file);

            }else{

                alert('Selecione um arquivo para carregar o conteúdo.');

            }
            
        }

        document.querySelector('form').addEventListener('submit', function(){

            const barra = document.getElementById('barra');

            let width = 0;

            const progresso = setInterval(() => {

                if (width >= 100) {

                    clearInterval(progresso);
                    
                }else{

                    width++;
                    barra.style.width = width + '%';
                    barra.textContent = width + '%';

                }
                
            }, 50);


        });

    </script>
    
</body>
</html>