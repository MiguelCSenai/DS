<?php

    include 'conexao.php';

    if (isset($_POST['salvar'])) {

        $arquivo = $_FILES['arquivo']['tmp_name'];

        if ($arquivo) {
            $conteudo = file_get_contents($arquivo);

            $linhas = explode("\n", $conteudo);

            foreach ($linhas as $linha) {
                if(!empty(trim($linha))){

                    list($nome, $telefone, $email, $cpf) = explode('|', $linha);

                    $sql = "INSERT INTO clientes(nome, telefone, email, cpf)
                            VALUES('$nome', '$telefone', '$email', '$cpf')";

                    if (!myqli_query($conn, $sql)) {
                        echo "Erro ao inserir dados: " . mysqli_error($conn);
                    }

                }
            }

            echo "Dados inseridos com sucesso!";

        }else {

            echo "Nenhum arquivo foi enviado.";
            
        }


    }

?>